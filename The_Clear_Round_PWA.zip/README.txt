# The Clear Round — Show Day Mode (PWA)

Files:
- index.html — the original app, with PWA metadata/registration added
- manifest.json — installable app configuration
- service-worker.js — offline caching
- icon.svg — home-screen icon

IMPORTANT:
A PWA must be served from HTTPS (or localhost during development). Opening index.html
directly as a file will NOT enable the service worker or install prompt.

For testing on a phone, upload these files together to an HTTPS static host, then open
the resulting web address on the phone and use the browser's "Add to Home screen" /
"Install app" option.

The app continues to store show records in the browser's localStorage, exactly as the
original file does. It does not add a server/database or transmit show data.
